# OpenClaw Health Dashboard

这是一个可直接部署的前端项目，基于 **Vite + React + Tailwind**。

## 一句话启动

```bash
npm i && npm run dev
```

## 生产构建

```bash
npm run build
npm run preview
```

## 目录

- `src/App.jsx`：主页面
- `src/components/ui/*`：轻量 UI 组件
- `src/index.css`：Tailwind 入口
- `vite.config.js`：Vite 配置与 `@` 别名

## 交付说明

这个版本已经包含：

- 自检中心首页
- API 中转池 / 自动切换
- 错误码识别规则
- 模型回退优先级
- 手动切线 / 自动切线演示逻辑
- 高延迟与失败阈值控制

## 适合交给其他 AI 的提示词

```text
请在这个 Vite + React 项目基础上继续开发，并保持现有页面结构不变。
先做三件事：
1. 把 src/App.jsx 里的 mock 数据替换成真实 OpenClaw 后端接口
2. 保留 API 中转池、自动切换、模型回退优先级逻辑
3. 所有“模拟上游错误 / 模拟高延迟 / 手动切换 / 识别模型”按钮改成真实 API 调用
```
