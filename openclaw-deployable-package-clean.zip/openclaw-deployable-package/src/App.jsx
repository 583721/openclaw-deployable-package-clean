import React, { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertTriangle,
  CheckCircle2,
  Clock3,
  RefreshCcw,
  Server,
  Wifi,
  Activity,
  Coins,
  Wrench,
  RotateCcw,
  FileSearch,
  Settings2,
  Zap,
  Gauge,
  Scissors,
  Layers3,
  ArrowRight,
  ArrowRightLeft,
  ShieldCheck,
  KeyRound,
  PlugZap,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
} from "recharts";

const initialOverview = {
  serviceStatus: "healthy",
  networkStatus: "degraded",
  successRate: 98.4,
  avgLatencyMs: 824,
  p95LatencyMs: 2430,
  activeSessions: 12,
  activeTasks: 4,
  token: {
    input: 128000,
    output: 342000,
    total: 470000,
    estimatedCost: 12.84,
  },
  updatedAt: "2026-03-12 14:32:10",
};

const trendData = [
  { time: "14:00", avg: 720, p95: 1700, error: 0.6, input: 3200, output: 8300, connect: 110 },
  { time: "14:05", avg: 810, p95: 2200, error: 0.8, input: 4100, output: 9000, connect: 130 },
  { time: "14:10", avg: 790, p95: 2100, error: 1.1, input: 3900, output: 8600, connect: 125 },
  { time: "14:15", avg: 920, p95: 2600, error: 1.3, input: 4300, output: 9500, connect: 165 },
  { time: "14:20", avg: 860, p95: 2400, error: 0.9, input: 4000, output: 8800, connect: 140 },
  { time: "14:25", avg: 840, p95: 2350, error: 0.7, input: 4200, output: 9300, connect: 135 },
  { time: "14:30", avg: 824, p95: 2430, error: 0.9, input: 4500, output: 9700, connect: 150 },
];

const initialChecks = [
  { id: "provider", name: "Provider 连通性", status: "warn", durationMs: 1240, message: "连接较慢，但可用" },
  { id: "test", name: "最小业务请求", status: "warn", durationMs: 1860, message: "响应偏慢" },
  { id: "queue", name: "瞬时流量控制", status: "fail", durationMs: 220, message: "最近出现 429" },
];

const slowRequests = [
  { time: "14:29:10", api: "/v1/chat/completions", status: "200", latency: 3180, input: 1800, output: 2400, error: "-" },
  { time: "14:27:42", api: "/v1/responses", status: "504", latency: 5220, input: 1200, output: 0, error: "upstream timeout" },
  { time: "14:22:51", api: "/v1/chat/completions", status: "429", latency: 740, input: 900, output: 0, error: "rate limited" },
];

const quickActions = [
  { id: "fallback", title: "切换 Fallback", hint: "最快恢复可用性", icon: Layers3 },
  { id: "queue", title: "启用排队", hint: "优先压住 429", icon: Gauge },
  { id: "trim", title: "裁剪上下文", hint: "直接降低 Token", icon: Scissors },
  { id: "retry", title: "重建连接", hint: "适合流式异常", icon: ArrowRightLeft },
];

const actions = [
  {
    id: "provider-latency",
    title: "Provider 延迟升高",
    severity: "warn",
    summary: "当前链路变慢，优先切换备用 Provider。",
    gain: "响应时间预计下降 20%~40%",
    actions: ["重新探测", "切换备用 Provider", "降低并发"],
    cta: "立即切换",
  },
  {
    id: "rate-limit",
    title: "触发限流",
    severity: "fail",
    summary: "当前有 429，优先降低瞬时流量。",
    gain: "成功率预计回升 3%~8%",
    actions: ["启用排队模式", "切换低成本模型", "收紧请求频率"],
    cta: "立即限流",
  },
  {
    id: "token-spike",
    title: "Token 偏高",
    severity: "warn",
    summary: "先裁剪上下文和限制输出，最快止损。",
    gain: "Token 成本预计下降 15%~35%",
    actions: ["开启上下文裁剪", "限制最大输出", "优先命中缓存"],
    cta: "立即降本",
  },
];

const reasonTags = [
  { label: "upstream timeout", count: 3 },
  { label: "rate limited", count: 2 },
  { label: "connect slow", count: 4 },
];

const modelFallbackPriority = [
  "openai/gpt-5.4",
  "anthropic/claude-sonnet-4.6",
  "anthropic/claude-opus-4.6",
  "nvidia/nemotron-3-super-120b-a12b",
  "anthropic/claude-opus-4.5",
];

const initialApiPool = [
  {
    id: "line-a",
    name: "线路 A",
    provider: "OpenAI Relay",
    baseUrl: "https://api-a.example.com/v1",
    apiKey: "sk-a-demo-123456",
    status: "active",
    failCount: 2,
    highLatencyCount: 3,
    modelMode: "auto",
    manualModel: "gpt-4o-mini",
    detectedModels: ["openai/gpt-5.4", "gpt-4o-mini", "gpt-4.1-mini"],
    currentModel: "openai/gpt-5.4",
    lastCheck: "14:32:10",
    lastErrorHttp: 502,
    lastErrorCode: "upstream_unavailable",
  },
  {
    id: "line-b",
    name: "线路 B",
    provider: "Anthropic Relay",
    baseUrl: "https://api-b.example.com/v1",
    apiKey: "sk-b-demo-654321",
    status: "standby",
    failCount: 0,
    highLatencyCount: 1,
    modelMode: "manual",
    manualModel: "claude-3-7-sonnet",
    detectedModels: ["anthropic/claude-sonnet-4.6", "anthropic/claude-opus-4.6", "anthropic/claude-opus-4.5", "claude-3-7-sonnet"],
    currentModel: "anthropic/claude-sonnet-4.6",
    lastCheck: "14:31:48",
    lastErrorHttp: null,
    lastErrorCode: "",
  },
  {
    id: "line-c",
    name: "线路 C",
    provider: "Gemini Relay",
    baseUrl: "https://api-c.example.com/v1",
    apiKey: "sk-c-demo-246810",
    status: "standby",
    failCount: 1,
    highLatencyCount: 0,
    modelMode: "auto",
    manualModel: "gemini-2.0-flash",
    detectedModels: ["nvidia/nemotron-3-super-120b-a12b", "gemini-2.0-flash", "gemini-2.5-pro"],
    currentModel: "nvidia/nemotron-3-super-120b-a12b",
    lastCheck: "14:30:58",
    lastErrorHttp: 429,
    lastErrorCode: "insufficient_quota",
  },
];

const errorRules = {
  http: {
    400: { label: "请求参数错误", action: "检查参数", switch: false },
    401: { label: "认证失败", action: "检查 API Key", switch: false },
    403: { label: "权限不足", action: "检查模型权限", switch: false },
    404: { label: "路径或任务不存在", action: "检查 URL 或 task_id", switch: false },
    413: { label: "请求体过大", action: "减小上下文或文件", switch: false },
    429: { label: "请求频率超限", action: "降频或切换备用线路", switch: true },
    500: { label: "服务器内部错误", action: "稍后重试", switch: true },
    502: { label: "上游服务不可用", action: "直接切换备用线路", switch: true },
    503: { label: "服务暂不可用", action: "直接切换备用线路", switch: true },
  },
  code: {
    invalid_api_key: { label: "令牌无效", action: "检查 Key 是否正确", switch: false },
    insufficient_quota: { label: "额度不足", action: "切换仍有额度的线路", switch: true },
    model_not_found: { label: "模型不存在", action: "识别模型并更新映射", switch: false },
    context_length_exceeded: { label: "上下文过长", action: "裁剪上下文", switch: false },
    unsupported_endpoint: { label: "接口不支持", action: "切换到兼容接口或线路", switch: false },
    upstream_unavailable: { label: "上游不可用", action: "直接切换备用线路", switch: true },
  },
};

const initialRecentRuns = [
  { time: "14:33:10", action: "切换备用 Provider", result: "成功", detail: "平均响应从 1.2s 回落到 820ms" },
  { time: "14:29:42", action: "启用排队模式", result: "成功", detail: "429 从 4 次降到 1 次" },
  { time: "14:25:05", action: "裁剪上下文", result: "成功", detail: "单请求 Token 降低约 18%" },
];

function statusColor(status) {
  if (status === "healthy" || status === "pass") return "bg-emerald-500";
  if (status === "degraded" || status === "warn") return "bg-amber-500";
  return "bg-rose-500";
}

function statusText(status) {
  if (status === "healthy") return "正常";
  if (status === "degraded") return "降级";
  if (status === "unhealthy") return "异常";
  if (status === "pass") return "通过";
  if (status === "warn") return "警告";
  if (status === "fail") return "失败";
  return "未知";
}

function severityBadge(status) {
  if (status === "pass") return "bg-emerald-100 text-emerald-700";
  if (status === "warn") return "bg-amber-100 text-amber-700";
  return "bg-rose-100 text-rose-700";
}

function SummaryCard({ title, value, sub, icon: Icon, status }) {
  return (
    <Card className="rounded-2xl border-0 bg-white/80 shadow-sm backdrop-blur">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-sm text-slate-500">{title}</p>
            <div className="mt-2 flex items-center gap-2">
              <p className="text-2xl font-semibold text-slate-900">{value}</p>
              {status ? <span className={`inline-block h-2.5 w-2.5 rounded-full ${statusColor(status)}`} /> : null}
            </div>
            <p className="mt-1 text-xs text-slate-500">{sub}</p>
          </div>
          <div className="rounded-2xl bg-slate-100 p-3">
            <Icon className="h-5 w-5 text-slate-700" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function SectionTitle({ title, right }) {
  return (
    <div className="mb-3 flex items-center justify-between gap-3">
      <h2 className="text-base font-semibold text-slate-900">{title}</h2>
      {right}
    </div>
  );
}

export default function App() {
  const [range, setRange] = useState("1h");
  const [overview, setOverview] = useState(initialOverview);
  const [checks, setChecks] = useState(initialChecks);
  const [recentRuns, setRecentRuns] = useState(initialRecentRuns);
  const [activeIssue, setActiveIssue] = useState("provider-latency");
  const [apiPool, setApiPool] = useState(initialApiPool);
  const [autoSwitchEnabled, setAutoSwitchEnabled] = useState(true);
  const [failThreshold, setFailThreshold] = useState(5);
  const [latencyThreshold, setLatencyThreshold] = useState(1500);
  const [latencyThresholdCount, setLatencyThresholdCount] = useState(5);
  const topAction = actions.find((item) => item.id === activeIssue) || actions[0];

  const activeApi = apiPool.find((item) => item.status === "active") || apiPool[0];

  const summary = useMemo(() => {
    const failCount = checks.filter((item) => item.status === "fail").length;
    const warnCount = checks.filter((item) => item.status === "warn").length;
    const recovered = recentRuns.filter((item) => item.result === "成功").length;
    return {
      failed: failCount,
      warned: warnCount,
      recovered,
    };
  }, [checks, recentRuns]);

  const maskKey = (key) => (key ? `${key.slice(0, 6)}••••${key.slice(-4)}` : "未填写");

  const pushRun = (action, detail) => {
    setRecentRuns((prev) => [
      { time: "刚刚", action, result: "成功", detail },
      ...prev.slice(0, 3),
    ]);
  };

  const pickBestModel = (models = []) => {
    for (const target of modelFallbackPriority) {
      if (models.includes(target)) return target;
    }
    return models[0] || "";
  };

  const resolvePreferredApi = (pool) => {
    const gpt54Apis = pool.filter((item) => (item.detectedModels || []).includes("openai/gpt-5.4"));
    if (gpt54Apis.length > 0) return gpt54Apis[0];
    for (const model of modelFallbackPriority.slice(1)) {
      const match = pool.find((item) => (item.detectedModels || []).includes(model));
      if (match) return match;
    }
    return pool.find((item) => item.status !== "disabled") || pool[0];
  };

  const getErrorMeta = (httpStatus, errorCode) => {
    const httpMeta = httpStatus ? errorRules.http[httpStatus] : null;
    const codeMeta = errorCode ? errorRules.code[errorCode] : null;
    return codeMeta || httpMeta || { label: "未知错误", action: "查看日志", switch: false };
  };

  const switchApi = (targetId, reason = "手动切换") => {
    setApiPool((prev) =>
      prev.map((item) => {
        if (item.id === targetId) {
          const currentModel = item.modelMode === "manual" ? item.manualModel : pickBestModel(item.detectedModels || []) || item.currentModel || item.manualModel;
          return { ...item, status: "active", failCount: 0, highLatencyCount: 0, currentModel, lastCheck: "刚刚" };
        }
        return { ...item, status: item.status === "active" ? "standby" : item.status };
      })
    );
    const target = apiPool.find((item) => item.id === targetId);
    if (target) {
      const nextModel = target.modelMode === "manual" ? target.manualModel : pickBestModel(target.detectedModels || []) || target.currentModel;
      pushRun(`切换到 ${target.name}`, `${reason}，当前模型 ${nextModel}`);
      setOverview((prev) => ({ ...prev, updatedAt: "2026-03-12 14:36:20", networkStatus: "healthy" }));
    }
  };

  const detectModels = (targetId) => {
    setApiPool((prev) =>
      prev.map((item) =>
        item.id === targetId
          ? {
              ...item,
              detectedModels: [...new Set([item.currentModel, item.manualModel, ...(item.detectedModels || [])].filter(Boolean))],
              currentModel: item.modelMode === "manual" ? item.manualModel : pickBestModel(item.detectedModels || []) || item.currentModel || item.manualModel,
              lastCheck: "刚刚",
            }
          : item
      )
    );
    const target = apiPool.find((item) => item.id === targetId);
    pushRun(`识别 ${target?.name || "线路"} 模型`, "已更新可用模型列表");
  };

  const updateApiField = (targetId, field, value) => {
    setApiPool((prev) =>
      prev.map((item) => {
        if (item.id !== targetId) return item;
        const next = { ...item, [field]: value };
        if (field === "manualModel" && item.modelMode === "manual") next.currentModel = value;
        if (field === "modelMode") next.currentModel = value === "manual" ? next.manualModel : pickBestModel(next.detectedModels || []) || next.currentModel || next.manualModel;
        return next;
      })
    );
  };

  const registerFailure = (targetId, reason = "响应失败", httpStatus = null, errorCode = "") => {
    let shouldSwitchTo = null;
    let shouldSwitch = false;
    const errorMeta = getErrorMeta(httpStatus, errorCode);
    setApiPool((prev) => {
      const next = prev.map((item) => {
        if (item.id !== targetId) return item;
        const nextFail = item.failCount + 1;
        shouldSwitch = !!errorMeta.switch || (item.status === "active" && autoSwitchEnabled && nextFail >= failThreshold);
        if (item.status === "active" && autoSwitchEnabled && shouldSwitch) {
          const backup = prev.find((line) => line.id !== targetId && line.status !== "disabled");
          if (backup) shouldSwitchTo = backup.id;
        }
        return {
          ...item,
          failCount: nextFail,
          lastCheck: "刚刚",
          lastErrorHttp: httpStatus,
          lastErrorCode: errorCode,
        };
      });
      return next;
    });

    const target = apiPool.find((item) => item.id === targetId);
    const nextFail = (target?.failCount || 0) + 1;
    pushRun(
      `${target?.name || "当前线路"} 失败 +1`,
      `${reason}${httpStatus ? ` · HTTP ${httpStatus}` : ""}${errorCode ? ` · ${errorCode}` : ""}，累计 ${nextFail}/${failThreshold}`
    );
    if (shouldSwitchTo) {
      const bestApi = resolvePreferredApi(apiPool.filter((item) => item.id !== targetId && item.status !== "disabled"));
      const finalTargetId = bestApi?.id || shouldSwitchTo;
      switchApi(finalTargetId, errorMeta.switch ? `${errorMeta.label}，无感切换` : `连续失败 ${failThreshold} 次自动切换`);
    }
  };

  const registerLatency = (targetId, latencyMs) => {
    let shouldSwitchTo = null;
    setApiPool((prev) => {
      const next = prev.map((item) => {
        if (item.id !== targetId) return item;
        const over = latencyMs >= latencyThreshold;
        const nextCount = over ? item.highLatencyCount + 1 : 0;
        if (item.status === "active" && autoSwitchEnabled && nextCount >= latencyThresholdCount) {
          const backup = prev.find((line) => line.id !== targetId && line.status !== "disabled");
          if (backup) shouldSwitchTo = backup.id;
        }
        return { ...item, highLatencyCount: nextCount, lastCheck: "刚刚" };
      });
      return next;
    });
    pushRun(`${activeApi.name} 高延迟`, `${latencyMs}ms，连续高延迟计数 +1`);
    if (shouldSwitchTo) {
      const bestApi = resolvePreferredApi(apiPool.filter((item) => item.id !== targetId && item.status !== "disabled"));
      switchApi(bestApi?.id || shouldSwitchTo, `连续高延迟达到 ${latencyThresholdCount} 次自动切换`);
    }
  };

  const runQuickAction = (id) => {
    if (id === "fallback") {
      setActiveIssue("provider-latency");
      setOverview((prev) => ({ ...prev, networkStatus: "healthy", avgLatencyMs: 690, p95LatencyMs: 1880, updatedAt: "2026-03-12 14:36:20" }));
      setChecks((prev) => prev.map((item) => item.id === "provider" ? { ...item, status: "pass", message: "已切到备用 Provider" } : item));
      pushRun("切换 Fallback", "网络状态恢复正常，平均响应下降到 690ms");
      return;
    }
    if (id === "queue") {
      setActiveIssue("rate-limit");
      setOverview((prev) => ({ ...prev, successRate: 99.1, updatedAt: "2026-03-12 14:36:20" }));
      setChecks((prev) => prev.map((item) => item.id === "queue" ? { ...item, status: "warn", message: "已启用排队，429 明显下降" } : item));
      pushRun("启用排队模式", "成功率提升到 99.1%，429 降为偶发");
      return;
    }
    if (id === "trim") {
      setActiveIssue("token-spike");
      setOverview((prev) => ({
        ...prev,
        token: {
          ...prev.token,
          total: 421000,
          estimatedCost: 11.26,
        },
        updatedAt: "2026-03-12 14:36:20",
      }));
      pushRun("裁剪上下文", "总 Token 降到 421,000，成本同步下降");
      return;
    }
    registerFailure(activeApi.id, "断连/流式异常后重建连接", 502, "upstream_unavailable");
    pushRun("重建连接", "流式连接已重建，建议执行后复检");
  };

  const runFix = (issueId) => {
    setActiveIssue(issueId);
    if (issueId === "provider-latency") {
      runQuickAction("fallback");
      return;
    }
    if (issueId === "rate-limit") {
      runQuickAction("queue");
      return;
    }
    runQuickAction("trim");
  };

  const rerunChecks = () => {
    setChecks((prev) =>
      prev.map((item) =>
        item.status === "fail"
          ? { ...item, status: "warn", message: "复检后仍需观察" }
          : { ...item, status: item.status === "warn" ? "pass" : item.status }
      )
    );
    pushRun("快速复检", "关键链路复检完成，仍保留 1 个待观察项");
    setOverview((prev) => ({ ...prev, updatedAt: "2026-03-12 14:36:20" }));
  };

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="flex flex-col gap-4 rounded-3xl bg-gradient-to-r from-slate-900 to-slate-800 p-6 text-white shadow-lg md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-semibold tracking-tight">OpenClaw 自检中心</h1>
            <p className="mt-2 text-sm text-slate-300">优先给出当前最值得执行的优化动作</p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <Badge className="rounded-full bg-white/10 px-3 py-1 text-white hover:bg-white/10">更新时间：{overview.updatedAt}</Badge>
            <Button variant="secondary" className="rounded-2xl gap-2" onClick={rerunChecks}>
              <RefreshCcw className="h-4 w-4" />
              快速自检
            </Button>
          </div>
        </div>

        <Card className="overflow-hidden rounded-3xl border-0 bg-white shadow-sm">
          <CardContent className="grid p-0 lg:grid-cols-[1.35fr_0.95fr]">
            <div className="bg-gradient-to-r from-amber-50 to-white p-6">
              <div className="inline-flex rounded-full bg-amber-100 px-2.5 py-1 text-xs font-medium text-amber-700">当前第一优先级</div>
              <h2 className="mt-3 text-2xl font-semibold text-slate-900">{topAction.title}</h2>
              <p className="mt-2 text-sm text-slate-600">{topAction.summary}</p>
              <div className="mt-4 grid gap-3 md:grid-cols-3">
                <div className="rounded-2xl bg-white p-4 shadow-sm">
                  <p className="text-xs text-slate-500">当前表现</p>
                  <p className="mt-1 text-xl font-semibold text-slate-900">150 ms</p>
                  <p className="text-xs text-slate-500">connect latency</p>
                </div>
                <div className="rounded-2xl bg-white p-4 shadow-sm">
                  <p className="text-xs text-slate-500">最小请求</p>
                  <p className="mt-1 text-xl font-semibold text-slate-900">1.86 s</p>
                  <p className="text-xs text-slate-500">当前偏慢</p>
                </div>
                <div className="rounded-2xl bg-white p-4 shadow-sm">
                  <p className="text-xs text-slate-500">预期收益</p>
                  <p className="mt-1 text-xl font-semibold text-slate-900">20%~40%</p>
                  <p className="text-xs text-slate-500">响应下降空间</p>
                </div>
              </div>
              <div className="mt-5 flex flex-wrap gap-3">
                <Button className="rounded-2xl gap-2" onClick={() => runFix(topAction.id)}>
                  <Wrench className="h-4 w-4" />
                  {topAction.cta}
                </Button>
                <Button variant="outline" className="rounded-2xl gap-2" onClick={rerunChecks}>
                  <RotateCcw className="h-4 w-4" />
                  执行后复检
                </Button>
                <Button variant="ghost" className="rounded-2xl gap-2">
                  <FileSearch className="h-4 w-4" />
                  查看日志
                </Button>
              </div>
            </div>
            <div className="border-l border-slate-100 bg-white p-6">
              <SectionTitle title="快捷止损" right={<Badge variant="secondary" className="rounded-full">4 个动作</Badge>} />
              <div className="space-y-3">
                {quickActions.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => runQuickAction(item.id)}
                      className="flex w-full items-center justify-between rounded-2xl border border-slate-200 p-4 text-left transition hover:bg-slate-50"
                    >
                      <div className="flex items-center gap-3">
                        <div className="rounded-2xl bg-slate-100 p-2"><Icon className="h-4 w-4 text-slate-700" /></div>
                        <div>
                          <p className="text-sm font-medium text-slate-900">{item.title}</p>
                          <p className="text-xs text-slate-500">{item.hint}</p>
                        </div>
                      </div>
                      <ArrowRight className="h-4 w-4 text-slate-400" />
                    </button>
                  );
                })}
              </div>
              <div className="mt-5 rounded-2xl bg-slate-50 p-4">
                <p className="text-sm font-medium text-slate-800">修复自检</p>
                <p className="mt-1 text-xs text-slate-500">执行动作后自动复检 Provider、最小请求和 Token 采集。</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-3xl border-0 bg-white shadow-sm">
          <CardHeader>
            <SectionTitle
              title="API 中转池 / 自动切换"
              right={
                <div className="flex flex-wrap items-center gap-2">
                  <Badge variant="secondary" className="rounded-full">当前线路：{activeApi.name}</Badge>
                  <Button
                    variant={autoSwitchEnabled ? "secondary" : "outline"}
                    className="rounded-2xl gap-2"
                    onClick={() => setAutoSwitchEnabled((prev) => !prev)}
                  >
                    <PlugZap className="h-4 w-4" />
                    {autoSwitchEnabled ? "自动切换已开启" : "自动切换已关闭"}
                  </Button>
                </div>
              }
            />
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 lg:grid-cols-[1.15fr_2fr]">
              <div className="rounded-2xl bg-slate-50 p-4">
                <p className="text-sm font-medium text-slate-800">切换规则</p>
                <div className="mt-3 grid gap-3 sm:grid-cols-2">
                  <div className="rounded-2xl bg-white p-4 shadow-sm">
                    <p className="text-xs text-slate-500">高延迟阈值</p>
                    <div className="mt-2 flex items-center gap-2">
                      <input
                        type="number"
                        min="100"
                        step="100"
                        value={latencyThreshold}
                        onChange={(e) => setLatencyThreshold(Number(e.target.value) || 1500)}
                        className="w-24 rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none"
                      />
                      <span className="text-sm text-slate-500">ms</span>
                    </div>
                  </div>
                  <div className="rounded-2xl bg-white p-4 shadow-sm">
                    <p className="text-xs text-slate-500">高延迟切换次数</p>
                    <div className="mt-2 flex items-center gap-2">
                      <input
                        type="number"
                        min="1"
                        max="20"
                        value={latencyThresholdCount}
                        onChange={(e) => setLatencyThresholdCount(Number(e.target.value) || 5)}
                        className="w-20 rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none"
                      />
                      <span className="text-sm text-slate-500">次后自动切换</span>
                    </div>
                  </div>
                  <div className="rounded-2xl bg-white p-4 shadow-sm">
                    <p className="text-xs text-slate-500">失败 / 断连阈值</p>
                    <div className="mt-2 flex items-center gap-2">
                      <input
                        type="number"
                        min="1"
                        max="20"
                        value={failThreshold}
                        onChange={(e) => setFailThreshold(Number(e.target.value) || 5)}
                        className="w-20 rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none"
                      />
                      <span className="text-sm text-slate-500">次后自动切换</span>
                    </div>
                  </div>
                  <div className="rounded-2xl bg-white p-4 shadow-sm">
                    <p className="text-xs text-slate-500">当前模型</p>
                    <p className="mt-2 text-base font-semibold text-slate-900 break-all">{activeApi.currentModel}</p>
                    <p className="mt-1 text-[11px] text-slate-500">默认优先：openai/gpt-5.4</p>
                    <p className="mt-1 text-xs text-slate-500 break-all">{activeApi.baseUrl}</p>
                  </div>
                </div>
                <div className="mt-3 rounded-2xl border border-dashed border-slate-200 bg-white p-4 text-sm text-slate-600">
                  {autoSwitchEnabled
                    ? `当前默认优先使用 openai/gpt-5.4；当所有 5.4 不可用时，会按 anthropic/claude-sonnet-4.6 → anthropic/claude-opus-4.6 → nvidia/nemotron-3-super-120b-a12b → anthropic/claude-opus-4.5 顺序回退。线路遇到 429 / 500 / 502 / 503 / insufficient_quota / upstream_unavailable 会直接无感切换；连续失败达到 ${failThreshold} 次，或高延迟超过 ${latencyThreshold}ms 且累计 ${latencyThresholdCount} 次后，也会自动切换。`
                    : "当前已关闭自动切换，只能手动切换线路。"}
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                {apiPool.map((api) => (
                  <div key={api.id} className={`rounded-2xl border p-4 ${api.status === "active" ? "border-slate-900 bg-slate-50" : "border-slate-200 bg-white"}`}>
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="text-base font-semibold text-slate-900">{api.name}</p>
                          <Badge variant="outline" className="rounded-full">{api.provider}</Badge>
                          <Badge variant={api.status === "active" ? "default" : "secondary"} className="rounded-full">{api.status === "active" ? "当前使用" : "待命"}</Badge>
                        </div>
                        <p className="mt-1 text-xs text-slate-500 break-all">{api.baseUrl}</p>
                      </div>
                      <KeyRound className="h-4 w-4 text-slate-400" />
                    </div>

                    <div className="mt-4 space-y-3">
                      <div>
                        <p className="mb-1 text-xs text-slate-500">API 地址（以 /v1 结尾）</p>
                        <input
                          value={api.baseUrl}
                          onChange={(e) => updateApiField(api.id, "baseUrl", e.target.value)}
                          className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none"
                        />
                      </div>
                      <div>
                        <p className="mb-1 text-xs text-slate-500">API Key</p>
                        <input
                          value={api.apiKey}
                          onChange={(e) => updateApiField(api.id, "apiKey", e.target.value)}
                          className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none"
                        />
                        <p className="mt-1 text-[11px] text-slate-400">当前显示：{maskKey(api.apiKey)}</p>
                      </div>
                      <div className="grid gap-3 sm:grid-cols-2">
                        <div>
                          <p className="mb-1 text-xs text-slate-500">供应商名称</p>
                          <input
                            value={api.provider}
                            onChange={(e) => updateApiField(api.id, "provider", e.target.value)}
                            className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none"
                          />
                        </div>
                        <div>
                          <p className="mb-1 text-xs text-slate-500">模型模式</p>
                          <select
                            value={api.modelMode}
                            onChange={(e) => updateApiField(api.id, "modelMode", e.target.value)}
                            className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none"
                          >
                            <option value="auto">自动识别</option>
                            <option value="manual">手动填写</option>
                          </select>
                        </div>
                        <div>
                          <p className="mb-1 text-xs text-slate-500">失败计数</p>
                          <div className="rounded-xl border border-slate-200 px-3 py-2 text-sm text-slate-700">{api.failCount} / {failThreshold}</div>
                        </div>
                        <div>
                          <p className="mb-1 text-xs text-slate-500">高延迟计数</p>
                          <div className="rounded-xl border border-slate-200 px-3 py-2 text-sm text-slate-700">{api.highLatencyCount} / {latencyThresholdCount}</div>
                        </div>
                      </div>
                      <div>
                        <p className="mb-1 text-xs text-slate-500">模型名称</p>
                        <input
                          value={api.manualModel}
                          onChange={(e) => updateApiField(api.id, "manualModel", e.target.value)}
                          disabled={api.modelMode !== "manual"}
                          className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none disabled:bg-slate-100 disabled:text-slate-400"
                          placeholder="手动填写模型名"
                        />
                      </div>
                      <div>
                        <p className="mb-2 text-xs text-slate-500">错误识别</p>
                        <div className="rounded-2xl bg-slate-50 p-3 text-xs text-slate-600">
                          <div className="flex items-center justify-between gap-3">
                            <span>HTTP 状态</span>
                            <span className="font-medium text-slate-900">{api.lastErrorHttp || "-"}</span>
                          </div>
                          <div className="mt-2 flex items-center justify-between gap-3">
                            <span>错误代码</span>
                            <span className="font-medium text-slate-900 break-all">{api.lastErrorCode || "-"}</span>
                          </div>
                          <div className="mt-2 rounded-xl bg-white p-2 text-[11px] text-slate-500">
                            {getErrorMeta(api.lastErrorHttp, api.lastErrorCode).label} · {getErrorMeta(api.lastErrorHttp, api.lastErrorCode).action}
                          </div>
                        </div>
                      </div>
                      <div>
                        <p className="mb-2 text-xs text-slate-500">模型优先级命中</p>
                        <div className="rounded-2xl bg-slate-50 p-3 text-xs text-slate-600">
                          当前将优先命中：<span className="font-medium text-slate-900">{pickBestModel(api.detectedModels || []) || "未识别"}</span>
                        </div>
                      </div>
                      <div>
                        <p className="mb-2 text-xs text-slate-500">已识别模型</p>
                        <div className="flex flex-wrap gap-2">
                          {(api.detectedModels || []).map((model) => (
                            <Badge key={model} variant="secondary" className="rounded-full">{model}</Badge>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 flex flex-wrap gap-2">
                      <Button size="sm" className="rounded-xl" onClick={() => switchApi(api.id, "手动切换")}>切换到此 API</Button>
                      <Button size="sm" variant="outline" className="rounded-xl" onClick={() => detectModels(api.id)}>识别模型</Button>
                      <Button size="sm" variant="outline" className="rounded-xl" onClick={() => registerFailure(api.id, "模拟上游错误", 502, "upstream_unavailable")}>模拟上游错误</Button>
                      <Button size="sm" variant="outline" className="rounded-xl" onClick={() => registerLatency(api.id, 1800)}>模拟高延迟</Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-6">
          <SummaryCard title="服务状态" value={statusText(overview.serviceStatus)} sub="核心服务与网关健康度" icon={Server} status={overview.serviceStatus} />
          <SummaryCard title="网络状态" value={statusText(overview.networkStatus)} sub="Provider 连通性与链路质量" icon={Wifi} status={overview.networkStatus} />
          <SummaryCard title="成功率" value={`${overview.successRate}%`} sub="最近 5 分钟请求成功率" icon={CheckCircle2} />
          <SummaryCard title="平均响应" value={`${overview.avgLatencyMs} ms`} sub={`P95 ${overview.p95LatencyMs} ms`} icon={Clock3} />
          <SummaryCard title="今日 Token" value={overview.token.total.toLocaleString()} sub={`输入 ${overview.token.input.toLocaleString()} / 输出 ${overview.token.output.toLocaleString()}`} icon={Coins} />
          <SummaryCard title="活跃任务" value={`${overview.activeTasks}`} sub={`会话 ${overview.activeSessions} · 成本 $${overview.token.estimatedCost}`} icon={Activity} />
        </div>

        <div className="grid gap-4 xl:grid-cols-3">
          <Card className="rounded-3xl border-0 bg-white shadow-sm xl:col-span-2">
            <CardHeader className="pb-2">
              <SectionTitle
                title="性能与稳定性趋势"
                right={
                  <Tabs value={range} onValueChange={setRange}>
                    <TabsList className="rounded-2xl">
                      <TabsTrigger value="5m">5m</TabsTrigger>
                      <TabsTrigger value="1h">1h</TabsTrigger>
                      <TabsTrigger value="24h">24h</TabsTrigger>
                    </TabsList>
                  </Tabs>
                }
              />
            </CardHeader>
            <CardContent className="grid gap-4 p-6 pt-2 md:grid-cols-2">
              <div className="rounded-2xl bg-slate-50 p-4">
                <p className="mb-3 text-sm font-medium text-slate-700">响应时间趋势</p>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={trendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="avg" strokeWidth={2} dot={false} />
                      <Line type="monotone" dataKey="p95" strokeWidth={2} dot={false} strokeOpacity={0.45} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div className="rounded-2xl bg-slate-50 p-4">
                <p className="mb-3 text-sm font-medium text-slate-700">错误率趋势</p>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={trendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Area type="monotone" dataKey="error" strokeWidth={2} fillOpacity={0.2} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div className="rounded-2xl bg-slate-50 p-4">
                <p className="mb-3 text-sm font-medium text-slate-700">Token 趋势</p>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={trendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="input" radius={[8, 8, 0, 0]} />
                      <Bar dataKey="output" radius={[8, 8, 0, 0]} fillOpacity={0.45} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div className="rounded-2xl bg-slate-50 p-4">
                <p className="mb-3 text-sm font-medium text-slate-700">网络连接质量</p>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={trendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="connect" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-4">
            <Card className="rounded-3xl border-0 bg-white shadow-sm">
              <CardHeader>
                <CardTitle className="text-base">异常摘要</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-3 gap-3">
                <div className="rounded-2xl bg-rose-50 p-4">
                  <p className="text-xs text-slate-500">失败请求</p>
                  <p className="mt-1 text-2xl font-semibold text-slate-900">{summary.failed}</p>
                </div>
                <div className="rounded-2xl bg-amber-50 p-4">
                  <p className="text-xs text-slate-500">429 次数</p>
                  <p className="mt-1 text-2xl font-semibold text-slate-900">{summary.warned}</p>
                </div>
                <div className="rounded-2xl bg-emerald-50 p-4">
                  <p className="text-xs text-slate-500">已恢复</p>
                  <p className="mt-1 text-2xl font-semibold text-slate-900">{summary.recovered}</p>
                </div>
              </CardContent>
            </Card>

            <Card className="rounded-3xl border-0 bg-white shadow-sm">
              <CardHeader>
                <CardTitle className="text-base">当前告警</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="mt-0.5 h-5 w-5 text-amber-600" />
                    <div className="flex-1">
                      <p className="font-medium text-slate-900">Provider 延迟升高</p>
                      <p className="mt-1 text-sm text-slate-600">先切备用，再复检，不需要先看长链路细节。</p>
                      <div className="mt-3 flex flex-wrap gap-2">
                        <Button size="sm" className="rounded-xl gap-2" onClick={() => runFix("provider-latency")}>
                          <Wrench className="h-4 w-4" />
                          立即切换
                        </Button>
                        <Button size="sm" variant="outline" className="rounded-xl gap-2" onClick={rerunChecks}>
                          <RotateCcw className="h-4 w-4" />
                          执行后复检
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="rounded-2xl border border-rose-200 bg-rose-50 p-4">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="mt-0.5 h-5 w-5 text-rose-600" />
                    <div className="flex-1">
                      <p className="font-medium text-slate-900">检测到 429</p>
                      <p className="mt-1 text-sm text-slate-600">先启用排队模式或降低并发，优先保住成功率。</p>
                      <div className="mt-3 flex flex-wrap gap-2">
                        <Button size="sm" className="rounded-xl gap-2" onClick={() => runFix("rate-limit")}>
                          <Gauge className="h-4 w-4" />
                          立即限流
                        </Button>
                        <Button size="sm" variant="outline" className="rounded-xl gap-2" onClick={rerunChecks}>
                          <RotateCcw className="h-4 w-4" />
                          执行后复检
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="rounded-3xl border-0 bg-white shadow-sm">
              <CardHeader>
                <CardTitle className="text-base">最近操作 / 复检记录</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {recentRuns.map((item, idx) => (
                  <div key={idx} className="rounded-2xl border border-slate-200 p-3">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-sm font-medium text-slate-900">{item.action}</p>
                        <p className="mt-1 text-xs text-slate-500">{item.time}</p>
                      </div>
                      <Badge variant="secondary" className="rounded-full">{item.result}</Badge>
                    </div>
                    <p className="mt-2 text-xs text-slate-600">{item.detail}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="grid gap-4 xl:grid-cols-5">
          <Card className="rounded-3xl border-0 bg-white shadow-sm xl:col-span-5">
            <CardHeader>
              <SectionTitle
                title="立即处置"
                right={
                  <div className="flex flex-wrap gap-2">
                    <Button variant="outline" className="rounded-2xl gap-2" onClick={rerunChecks}>
                      <ShieldCheck className="h-4 w-4" />
                      快速复检
                    </Button>
                    <Button variant="outline" className="rounded-2xl gap-2">
                      <FileSearch className="h-4 w-4" />
                      查看日志
                    </Button>
                    <Button variant="outline" className="rounded-2xl gap-2">
                      <Settings2 className="h-4 w-4" />
                      打开配置
                    </Button>
                  </div>
                }
              />
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-3">
              {actions.map((item) => (
                <div key={item.id} className="rounded-2xl border border-slate-200 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${severityBadge(item.severity)}`}>{statusText(item.severity)}</div>
                      <p className="mt-3 text-base font-semibold text-slate-900">{item.title}</p>
                      <p className="mt-1 text-sm text-slate-600">{item.summary}</p>
                    </div>
                    <div className="rounded-2xl bg-slate-100 p-2"><Wrench className="h-4 w-4 text-slate-700" /></div>
                  </div>
                  <div className="mt-4 space-y-3 text-sm text-slate-600">
                    <div>
                      <p className="font-medium text-slate-800">现在做什么</p>
                      <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-slate-600">
                        {item.actions.map((a) => (
                          <li key={a}>{a}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="rounded-2xl bg-slate-50 p-3">
                      <p className="flex items-center gap-2 font-medium text-slate-800"><Zap className="h-4 w-4" />预期收益</p>
                      <p className="mt-1 text-sm text-slate-600">{item.gain}</p>
                    </div>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <Button className="rounded-xl gap-2" onClick={() => runFix(item.id)}>
                      <Wrench className="h-4 w-4" />
                      {item.cta}
                    </Button>
                    <Button variant="outline" className="rounded-xl gap-2" onClick={rerunChecks}>
                      <RotateCcw className="h-4 w-4" />
                      执行后复检
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="rounded-3xl border-0 bg-white shadow-sm xl:col-span-3">
            <CardHeader>
              <CardTitle className="text-base">模型回退优先级</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3 md:grid-cols-5">
                {modelFallbackPriority.map((model, idx) => (
                  <div key={model} className={`rounded-2xl border p-4 ${idx === 0 ? "border-slate-900 bg-slate-50" : "border-slate-200 bg-white"}`}>
                    <p className="text-xs text-slate-500">优先级 {idx + 1}</p>
                    <p className="mt-2 break-all text-sm font-medium text-slate-900">{model}</p>
                    {idx === 0 ? <Badge className="mt-3 rounded-full">默认模型</Badge> : null}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-3xl border-0 bg-white shadow-sm xl:col-span-3">
            <CardHeader>
              <CardTitle className="text-base">错误码识别规则</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="overflow-hidden rounded-2xl border border-slate-200">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 text-slate-500">
                    <tr>
                      <th className="px-4 py-3 font-medium">HTTP</th>
                      <th className="px-4 py-3 font-medium">说明</th>
                      <th className="px-4 py-3 font-medium">动作</th>
                      <th className="px-4 py-3 font-medium">切线</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(errorRules.http).map(([code, meta]) => (
                      <tr key={code} className="border-t border-slate-100">
                        <td className="px-4 py-3 font-medium text-slate-900">{code}</td>
                        <td className="px-4 py-3 text-slate-600">{meta.label}</td>
                        <td className="px-4 py-3 text-slate-600">{meta.action}</td>
                        <td className="px-4 py-3">{meta.switch ? <Badge className="rounded-full bg-rose-500 text-white">直接切换</Badge> : <Badge variant="secondary" className="rounded-full">不切换</Badge>}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="overflow-hidden rounded-2xl border border-slate-200">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 text-slate-500">
                    <tr>
                      <th className="px-4 py-3 font-medium">error.code</th>
                      <th className="px-4 py-3 font-medium">含义</th>
                      <th className="px-4 py-3 font-medium">动作</th>
                      <th className="px-4 py-3 font-medium">切线</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(errorRules.code).map(([code, meta]) => (
                      <tr key={code} className="border-t border-slate-100">
                        <td className="px-4 py-3 font-medium text-slate-900 break-all">{code}</td>
                        <td className="px-4 py-3 text-slate-600">{meta.label}</td>
                        <td className="px-4 py-3 text-slate-600">{meta.action}</td>
                        <td className="px-4 py-3">{meta.switch ? <Badge className="rounded-full bg-rose-500 text-white">直接切换</Badge> : <Badge variant="secondary" className="rounded-full">不切换</Badge>}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-3xl border-0 bg-white shadow-sm xl:col-span-2">
            <CardHeader>
              <SectionTitle
                title="异常自检项"
                right={
                  <div className="flex flex-wrap gap-2">
                    <Button variant="outline" className="rounded-2xl">只看异常</Button>
                    <Button variant="outline" className="rounded-2xl" onClick={rerunChecks}>重新检查全部</Button>
                  </div>
                }
              />
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto rounded-b-3xl">
                <table className="w-full min-w-[640px] text-left text-sm">
                  <thead className="bg-slate-50 text-slate-500">
                    <tr>
                      <th className="px-6 py-3 font-medium">检查项</th>
                      <th className="px-6 py-3 font-medium">状态</th>
                      <th className="px-6 py-3 font-medium">耗时</th>
                      <th className="px-6 py-3 font-medium">结果</th>
                      <th className="px-6 py-3 font-medium">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {checks.map((item) => (
                      <tr key={item.id} className="border-t border-slate-100">
                        <td className="px-6 py-4 font-medium text-slate-900">{item.name}</td>
                        <td className="px-6 py-4"><Badge className={`${statusColor(item.status)} text-white`}>{statusText(item.status)}</Badge></td>
                        <td className="px-6 py-4 text-slate-600">{item.durationMs} ms</td>
                        <td className="px-6 py-4 text-slate-600">{item.message}</td>
                        <td className="px-6 py-4">
                          <div className="flex flex-wrap gap-2">
                            <Button size="sm" variant="outline" className="rounded-xl" onClick={rerunChecks}>重试</Button>
                            <Button size="sm" variant="ghost" className="rounded-xl">查看日志</Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-3xl border-0 bg-white shadow-sm xl:col-span-2">
            <CardHeader>
              <CardTitle className="text-base">最近异常 / 慢请求</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex flex-wrap gap-2">
                {reasonTags.map((tag) => (
                  <Badge key={tag.label} variant="secondary" className="rounded-full">{tag.label} · {tag.count}</Badge>
                ))}
              </div>
              {slowRequests.map((row, idx) => (
                <div key={idx} className="rounded-2xl border border-slate-200 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-medium text-slate-900">{row.api}</p>
                      <p className="mt-1 text-xs text-slate-500">{row.time} · 状态 {row.status}</p>
                    </div>
                    <Badge variant="secondary" className="rounded-full">{row.latency} ms</Badge>
                  </div>
                  <div className="mt-3 grid grid-cols-3 gap-2 text-xs text-slate-600">
                    <div className="rounded-xl bg-slate-50 p-2">输入 {row.input}</div>
                    <div className="rounded-xl bg-slate-50 p-2">输出 {row.output}</div>
                    <div className="rounded-xl bg-slate-50 p-2">{row.error}</div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
