import React from 'react';

const variants = {
  default: 'bg-slate-900 text-white hover:bg-slate-800 border border-slate-900',
  secondary: 'bg-white text-slate-900 hover:bg-slate-100 border border-white',
  outline: 'bg-transparent text-slate-700 hover:bg-slate-50 border border-slate-200',
  ghost: 'bg-transparent text-slate-700 hover:bg-slate-100 border border-transparent',
};

const sizes = {
  default: 'h-10 px-4 py-2 text-sm',
  sm: 'h-9 px-3 py-2 text-sm',
};

export function Button({
  className = '',
  variant = 'default',
  size = 'default',
  type = 'button',
  children,
  ...props
}) {
  return (
    <button
      type={type}
      className={`inline-flex items-center justify-center whitespace-nowrap font-medium shadow-sm transition disabled:pointer-events-none disabled:opacity-50 ${variants[variant] || variants.default} ${sizes[size] || sizes.default} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
