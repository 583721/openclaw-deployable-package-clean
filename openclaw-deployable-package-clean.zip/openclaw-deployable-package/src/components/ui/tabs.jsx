import React, { createContext, useContext } from 'react';

const TabsContext = createContext({ value: '', onValueChange: () => {} });

export function Tabs({ value, onValueChange, children }) {
  return (
    <TabsContext.Provider value={{ value, onValueChange }}>
      {children}
    </TabsContext.Provider>
  );
}

export function TabsList({ className = '', children }) {
  return <div className={`inline-flex items-center gap-1 bg-slate-100 p-1 ${className}`}>{children}</div>;
}

export function TabsTrigger({ value, className = '', children }) {
  const ctx = useContext(TabsContext);
  const active = ctx.value === value;
  return (
    <button
      type="button"
      onClick={() => ctx.onValueChange(value)}
      className={`px-3 py-1.5 text-sm transition ${active ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'} ${className}`}
    >
      {children}
    </button>
  );
}
